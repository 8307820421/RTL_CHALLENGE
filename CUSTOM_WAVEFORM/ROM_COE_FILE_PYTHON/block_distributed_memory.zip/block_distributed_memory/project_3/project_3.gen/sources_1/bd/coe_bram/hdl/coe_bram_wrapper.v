//Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2022.2 (win64) Build 3671981 Fri Oct 14 05:00:03 MDT 2022
//Date        : Tue Jun 10 19:45:32 2025
//Host        : SONUTRIPATHI running 64-bit major release  (build 9200)
//Command     : generate_target coe_bram_wrapper.bd
//Design      : coe_bram_wrapper
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module coe_bram_wrapper
   (clk,
    douta_0);
  input clk;
  output [7:0]douta_0;

  wire clk;
  wire [7:0]douta_0;

  coe_bram coe_bram_i
       (.clk(clk),
        .douta_0(douta_0));
endmodule
