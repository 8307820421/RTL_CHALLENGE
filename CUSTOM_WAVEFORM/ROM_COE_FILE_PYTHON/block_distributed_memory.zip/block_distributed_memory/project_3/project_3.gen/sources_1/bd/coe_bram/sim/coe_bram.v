//Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2022.2 (win64) Build 3671981 Fri Oct 14 05:00:03 MDT 2022
//Date        : Tue Jun 10 19:45:32 2025
//Host        : SONUTRIPATHI running 64-bit major release  (build 9200)
//Command     : generate_target coe_bram.bd
//Design      : coe_bram
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CORE_GENERATION_INFO = "coe_bram,IP_Integrator,{x_ipVendor=xilinx.com,x_ipLibrary=BlockDiagram,x_ipName=coe_bram,x_ipVersion=1.00.a,x_ipLanguage=VERILOG,numBlks=2,numReposBlks=2,numNonXlnxBlks=0,numHierBlks=0,maxHierDepth=0,numSysgenBlks=0,numHlsBlks=0,numHdlrefBlks=0,numPkgbdBlks=0,bdsource=USER,synth_mode=OOC_per_IP}" *) (* HW_HANDOFF = "coe_bram.hwdef" *) 
module coe_bram
   (clk,
    douta_0);
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 CLK.CLK CLK" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME CLK.CLK, CLK_DOMAIN coe_bram_clka_0, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, INSERT_VIP 0, PHASE 0.0" *) input clk;
  output [7:0]douta_0;

  wire [7:0]blk_mem_gen_0_douta;
  wire [7:0]c_counter_binary_0_Q;
  wire clka_0_1;

  assign clka_0_1 = clk;
  assign douta_0[7:0] = blk_mem_gen_0_douta;
  coe_bram_blk_mem_gen_0_0 blk_mem_gen_0
       (.addra(c_counter_binary_0_Q),
        .clka(clka_0_1),
        .douta(blk_mem_gen_0_douta));
  coe_bram_c_counter_binary_0_0 c_counter_binary_0
       (.CLK(clka_0_1),
        .Q(c_counter_binary_0_Q));
endmodule
